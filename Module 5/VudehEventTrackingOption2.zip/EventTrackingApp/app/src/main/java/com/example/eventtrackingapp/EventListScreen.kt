package com.example.eventtrackingapp

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

data class Event(
    var title: String,
    var note: String = "",
    var date: String = "",
    var time: String = "",
    var isDone: Boolean = false,
    var isCancelled: Boolean = false
)

@Composable
fun EventListScreen(navController: NavHostController, userViewModel: UserViewModel) {
    val pendingEvents = remember { mutableStateListOf<Event>() }
    val completedEvents = remember { mutableStateListOf<Event>() }
    val cancelledEvents = remember { mutableStateListOf<Event>() }
    var newEventTitle by remember { mutableStateOf("") }
    var newEventNote by remember { mutableStateOf("") }
    var newEventDate by remember { mutableStateOf("") }
    var newEventTime by remember { mutableStateOf("") }
    var isEditing by remember { mutableStateOf(false) }
    var editingEventIndex by remember { mutableStateOf(-1) }
    var feedbackMessage by remember { mutableStateOf("") }
    var showPendingEvents by remember { mutableStateOf(true) }
    var showCompletedEvents by remember { mutableStateOf(true) }
    var showCancelledEvents by remember { mutableStateOf(true) }

    val dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            if (feedbackMessage.isNotEmpty()) {
                Text(
                    text = feedbackMessage,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }
            TextField(
                value = newEventTitle,
                onValueChange = { newEventTitle = it },
                label = { Text("Event Title") },
                modifier = Modifier.fillMaxWidth()
            )
            TextField(
                value = newEventNote,
                onValueChange = { newEventNote = it },
                label = { Text("Event Note") },
                modifier = Modifier.fillMaxWidth()
            )
            TextField(
                value = newEventDate,
                onValueChange = { newEventDate = it },
                label = { Text("Event Date (yyyy-MM-dd)") },
                modifier = Modifier.fillMaxWidth()
            )
            TextField(
                value = newEventTime,
                onValueChange = { newEventTime = it },
                label = { Text("Event Time (HH:mm)") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = {
                    if (newEventTitle.isNotBlank()) {
                        val event = Event(
                            title = newEventTitle,
                            note = newEventNote,
                            date = newEventDate,
                            time = newEventTime
                        )
                        if (isEditing && editingEventIndex != -1) {
                            if (event.isDone) {
                                completedEvents[editingEventIndex] = event
                            } else {
                                pendingEvents[editingEventIndex] = event
                            }
                            feedbackMessage = "Event updated: ${LocalDateTime.now().format(dateTimeFormatter)}"
                            isEditing = false
                            editingEventIndex = -1
                        } else {
                            pendingEvents.add(event)
                            feedbackMessage = "Event added: ${LocalDateTime.now().format(dateTimeFormatter)}"
                        }
                        newEventTitle = ""
                        newEventNote = ""
                        newEventDate = ""
                        newEventTime = ""
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (isEditing) "Update Event" else "Add Event")
            }
            Spacer(modifier = Modifier.height(16.dp))

            ToggleSection(title = "Pending Events", showSection = showPendingEvents, onToggle = { showPendingEvents = !showPendingEvents })
            if (showPendingEvents) {
                LazyColumn {
                    items(pendingEvents) { event ->
                        val index = pendingEvents.indexOf(event)
                        EventItem(
                            event = event,
                            onEdit = {
                                newEventTitle = event.title
                                newEventNote = event.note
                                newEventDate = event.date
                                newEventTime = event.time
                                isEditing = true
                                editingEventIndex = index
                            },
                            onDelete = { pendingEvents.removeAt(index) },
                            onToggleDone = {
                                event.isDone = !event.isDone
                                if (event.isDone) {
                                    pendingEvents.removeAt(index)
                                    completedEvents.add(event)
                                }
                            },
                            onToggleCancelled = {
                                event.isCancelled = !event.isCancelled
                                if (event.isCancelled) {
                                    pendingEvents.removeAt(index)
                                    cancelledEvents.add(event)
                                    feedbackMessage = "Event cancelled: ${LocalDateTime.now().format(dateTimeFormatter)}"
                                }
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            ToggleSection(title = "Completed Events", showSection = showCompletedEvents, onToggle = { showCompletedEvents = !showCompletedEvents })
            if (showCompletedEvents) {
                LazyColumn {
                    items(completedEvents) { event ->
                        val index = completedEvents.indexOf(event)
                        EventItem(
                            event = event,
                            onEdit = { /* No editing for completed events */ },
                            onDelete = { completedEvents.removeAt(index) },
                            onToggleDone = {
                                event.isDone = !event.isDone
                                if (!event.isDone) {
                                    completedEvents.removeAt(index)
                                    pendingEvents.add(event)
                                }
                            },
                            onToggleCancelled = { /* No cancelling for completed events */ }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            ToggleSection(title = "Cancelled Events", showSection = showCancelledEvents, onToggle = { showCancelledEvents = !showCancelledEvents })
            if (showCancelledEvents) {
                LazyColumn {
                    items(cancelledEvents) { event ->
                        val index = cancelledEvents.indexOf(event)
                        EventItem(
                            event = event,
                            onEdit = { /* No editing for cancelled events */ },
                            onDelete = { cancelledEvents.removeAt(index) },
                            onToggleDone = { /* No toggling done for cancelled events */ },
                            onToggleCancelled = {
                                event.isCancelled = !event.isCancelled
                                if (!event.isCancelled) {
                                    cancelledEvents.removeAt(index)
                                    pendingEvents.add(event)
                                }
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = {
                userViewModel.logout()
                navController.navigate("login") {
                    popUpTo(navController.graph.startDestinationId) {
                        inclusive = true
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Logout")
        }
    }
}

@Composable
fun ToggleSection(title: String, showSection: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable { onToggle() },
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = title, style = MaterialTheme.typography.titleLarge)
        Icon(
            imageVector = if (showSection) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
            contentDescription = if (showSection) "Hide $title" else "Show $title"
        )
    }
}

@Composable
fun EventItem(
    event: Event,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onToggleDone: () -> Unit,
    onToggleCancelled: () -> Unit
) {
    val context = LocalContext.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = event.title, style = MaterialTheme.typography.titleLarge)
                    Text(text = "Note: ${event.note}", style = MaterialTheme.typography.bodySmall)
                    Text(text = "Date: ${event.date}", style = MaterialTheme.typography.bodySmall)
                    Text(text = "Time: ${event.time}", style = MaterialTheme.typography.bodySmall)
                }
                Row {
                    if (!event.isDone && !event.isCancelled) {
                        IconButton(onClick = onEdit) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit")
                        }
                    }
                    IconButton(onClick = onDelete) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete")
                    }
                    IconButton(onClick = onToggleDone) {
                        Icon(
                            imageVector = if (event.isDone) Icons.Default.CheckCircle else Icons.Outlined.CheckCircle,
                            contentDescription = if (event.isDone) "Mark as not done" else "Mark as done",
                            tint = if (event.isDone) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    if (!event.isDone) {
                        IconButton(onClick = onToggleCancelled) {
                            Icon(
                                imageVector = if (event.isCancelled) Icons.Default.Cancel else Icons.Outlined.Cancel,
                                contentDescription = if (event.isCancelled) "Mark as not cancelled" else "Mark as cancelled",
                                tint = if (event.isCancelled) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                    IconButton(onClick = { shareEvent(event, context) }) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = "Share")
                    }
                }
            }
        }
    }
}

fun shareEvent(event: Event, context: Context) {
    val shareIntent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_TEXT, "Event: ${event.title}\nNote: ${event.note}\nDate: ${event.date}\nTime: ${event.time}")
        type = "text/plain"
    }
    context.startActivity(Intent.createChooser(shareIntent, null))
    Toast.makeText(context, "Sharing event...", Toast.LENGTH_SHORT).show()
}
