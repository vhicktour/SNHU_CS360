package com.example.vudehproject2;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSNotificationActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;
    private TextView smsPermissionStatus;
    private Button requestSmsPermissionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notification);

        smsPermissionStatus = findViewById(R.id.sms_permission_status);
        requestSmsPermissionButton = findViewById(R.id.request_sms_permission);

        updateSmsPermissionStatus();

        requestSmsPermissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSmsPermission();
            }
        });
    }

    private void updateSmsPermissionStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            smsPermissionStatus.setText("SMS Permission Granted");
        } else {
            smsPermissionStatus.setText("SMS Permission Denied");
